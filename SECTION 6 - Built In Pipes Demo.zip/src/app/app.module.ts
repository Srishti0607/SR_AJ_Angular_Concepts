import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PipesdemoComponent } from './pipesdemo/pipesdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    PipesdemoComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [PipesdemoComponent]
})
export class AppModule { }
