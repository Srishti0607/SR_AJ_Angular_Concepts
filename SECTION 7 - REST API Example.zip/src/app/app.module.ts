import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ShowallusersComponent } from './showallusers/showallusers.component';
import { GetuserdetailsComponent } from './getuserdetails/getuserdetails.component';
import { ViewchilddemoComponent } from './viewchilddemo/viewchilddemo.component';
import { ShowallusersusingcardsComponent } from './showallusersusingcards/showallusersusingcards.component';


@NgModule({
  declarations: [
    AppComponent,
    ShowallusersComponent,
    GetuserdetailsComponent,
    ViewchilddemoComponent,
    ShowallusersusingcardsComponent,
    
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [ShowallusersusingcardsComponent]
})
export class AppModule { }
