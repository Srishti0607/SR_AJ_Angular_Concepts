import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { IfdirectiveComponent } from './ifdirective/ifdirective.component';
import { LoadtemplateconditionallyComponent } from './loadtemplateconditionally/loadtemplateconditionally.component';
import { UsingngforwithformelementsComponent } from './usingngforwithformelements/usingngforwithformelements.component';

@NgModule({
  declarations: [
    AppComponent,
    IfdirectiveComponent,
    LoadtemplateconditionallyComponent,
    UsingngforwithformelementsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [UsingngforwithformelementsComponent]
})
export class AppModule { }
