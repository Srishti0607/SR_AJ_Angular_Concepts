import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { InLineComponent } from './components/inlinecomponent/inline.component';
import { CodeBehindComponent } from './components/codebehindcomponent/codebehind.component';
import { HelloWorldComponent } from './hello-world-component/hello-world-component.component';
@NgModule({
  declarations: [
    AppComponent,
    InLineComponent,
    CodeBehindComponent,
    HelloWorldComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [InLineComponent,CodeBehindComponent,HelloWorldComponent]
})
export class AppModule { }
