import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ShoppingcartexampleComponent } from './shoppingcartexample/shoppingcartexample.component';

@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartexampleComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [ShoppingcartexampleComponent]
})
export class AppModule { }
